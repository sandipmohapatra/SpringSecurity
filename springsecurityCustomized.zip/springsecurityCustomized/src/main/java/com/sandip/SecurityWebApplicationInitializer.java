package com.sandip;

import org.springframework.security.web.context.*;  
public class SecurityWebApplicationInitializer  
    extends AbstractSecurityWebApplicationInitializer {  
}  